#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#define tamanho 50



  typedef struct{;

    char time[30];
    char jogadores; [40]
    int codigo;
    char ender[40];
    char cidade[50];
    char estado[40];
    char ano[4];

  }Times;

Times menuTimes[tamanho];
